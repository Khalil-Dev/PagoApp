class AppEvent {
    constructor() {
        this.events = new Map();
    }

    on(eventName, eventHandler) {
        if(!this.events.has(eventName)) {
            this.events.set(eventName, []);
        }

        this.events.get(eventName).push(eventHandler);
    }

    clearEvent(eventName) {
        this.events.delete(eventName);
    }

    removeEvent(eventName, eventHandler) {
        if(!this.events.has(eventName)) {
            return;
        }

        const index = this.events.get(eventName).indexOf(element);

        if (index !== -1) {
            this.events.get(eventName).splice(index, 1);
        }
    }

    fire(eventName, data) {
        if(!this.events.has(eventName)) {
            return;
        }

        for(var handler of this.events.get(eventName)) {
            handler(data);
        }
    }

}

export default AppEvent;