import AppEvent from "./AppEvent";

class Model extends AppEvent {
    constructor(modelName) {
        super();
        this.modelName = modelName;
    }

    setData(data) {
        this.data = data;

        super.fire("data", this.data);
    }

    error(xhr, statusText, err) {
        super.fire("error", { xhr : xhr, statusText : statusText, err : err });
    }
}

export default Model;