export function dfn(v) {
    if(v === null) {
        return false;
    }

    return typeof v !== 'undefined';
}

const MONTHS = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];

export function getShortMonth(month) {
    return MONTHS[month];
}