import { log } from "./Logging";

const Net = {
    timeout : 60000,

    resolveURL : (url) => {
        return url;
    },

    get:(url, cb, f) => {
        let u = Net.resolveURL(url);

        log("GET url = " + u, "Net");
        $.ajax({
            url : u,
            type : "GET",
            timeout : Net.timeout,
            dataType : "json",
            success : (json) => cb(json),
            error: (xhr, status, error) => f(xhr, status, error)
        });
    },

    post:(url, params, cb, f) => {
        let u = Net.resolveURL(url);

        log("POST url = " + u, "Net");
        $.ajax({
            url : u,
            type : "POST",
            timeout : Net.timeout,
            dataType : "json",
            contentType: "application/json",
            data : JSON.stringify(params),
            success : (json) => {
                cb(json)
            },
            error: (xhr, status, error) => {
                f(xhr, status, error)
            }
        });

    },

    csvpost:(url, params, cb, f) => {
        let u = Net.resolveURL(url);

        log("POST url = " + u, "Net");
        $.ajax({
            url : u,
            type : "POST",
            timeout : Net.timeout,
            headers: {
             'Accept' : "text/csv; charset=utf-8"
            },
            contentType: "application/json",
            data : JSON.stringify(params),
            success : (json) => cb(json),
            error: (xhr, status, error) => f(xhr, status, error)
        });
    },

    ERR : (xhr, status, error) => {
        log("---------- NET ERROR");
        log(xhr);
        log(status);
        log(error)
        alert('An error occurred');
    }
};

export default Net;
