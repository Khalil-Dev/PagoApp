import {dfn} from "./Utils";
import {log} from "./Logging";

export const SpinnerOn = (msg) => {
    try {
        SpinnerPlugin.activityStart(msg);
    } catch(e) {
        log('no spinner');
    }
};

export const SpinnerOff = () => {
    try {
        SpinnerPlugin.activityStop();
    } catch(e) {
        log('no spinner off...');
    }
};

export const getPicture = (success, fail, opts) => {
    try {
        if(!dfn(opts)) {
            opts = {
                quality : 50,
                destinationType : Camera.DestinationType.DATA_URL,
                correctOrientation : true,
                cameraDirection : Camera.Direction.FRONT,
                targetWidth : 400,
                targetHeight: 400
            };
        }

        navigator.camera.getPicture(success, fail, opts);
    } catch(e) {
        log('no camera...');
        log(e);
    }

};