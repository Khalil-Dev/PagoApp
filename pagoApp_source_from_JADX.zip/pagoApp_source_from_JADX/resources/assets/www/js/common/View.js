import AppEvent from "./AppEvent";

class View extends AppEvent {
    constructor(element, model) {
        super();

        this.element = element;
        this.model = model;
    }
}

export default View;