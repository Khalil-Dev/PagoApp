let LoggingGlobals = {
    logging : true
}

const log = (msg, tab = "") => {
    if(LoggingGlobals.logging) {
        if(typeof msg !== 'object') {
            console.log('not object');
            console.log(tab + msg);
        } else {
            console.log(JSON.stringify(msg));
            // for(let k in msg) {
            //     if(typeof msg[k] === 'object') {
            //         console.log(tab + k);
            //         log(msg[k], tab + "\t")
            //     }
            // }
        }
    }
};

export { log };