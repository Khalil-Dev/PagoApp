import { dfn } from "../common/Utils";

class NativePhone {
    hideKeyboard() {
        try {
            if(dfn(Keyboard)) {
                Keyboard.hide();
            }
        } catch(e) {
        }

    }
}

const Native = new NativePhone();

export default Native;