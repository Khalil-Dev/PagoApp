import {dfn} from "./Utils";
import UserModel from "../models/UserModel";
import AppEvent from "./AppEvent";
import App from "../app/App";
import {log} from "./Logging";

class UserProfileImage extends AppEvent {
    constructor() {
        super();

        this.model = new UserModel();

        this.model.on('userProfileImage', (result) => {
            log("we have a profile : md5 = " + result.md5);
            if(result.img === 'NONE') {
                return;
            }

            this.fire('userProfileImage', result);
        });

        this.model.on('getUserProfileMD5', (result) => {
            if(!result.success) {
                return;
            }

            // images match
            log(result.meta.md5);
            log(App.getUserImage().md5)
            if(App.getUserImage().md5 === result.meta.md5) {
                log('img md5 matches');
                this.fire('userProfileImage', App.getUserImage());
                return;
            }

            // load image
            this.model.getUserProfile(this.userId);
        });
    }

    loadProfileImage(userId, checkMD5) {
        this.userId = userId;
        let img = App.getUserImage();

        // we have no user profile image so load it
        if(!dfn(img)) {
            log('no stored image, loading...');
            this.model.getUserProfile(userId);
            return;
        }

        // we assume profile img is up to date
        if(!dfn(checkMD5) || checkMD5 === false) {
            this.fire('userProfileImage', img);
            return;
        }

        // check md5
        log('checking img for match');
        this.model.getUserProfileMD5(userId);
    }
}

export default UserProfileImage;