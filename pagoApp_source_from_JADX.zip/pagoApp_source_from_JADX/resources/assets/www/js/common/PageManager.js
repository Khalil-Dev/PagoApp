import {dfn} from "./Utils";
import {log} from "./Logging";
import Native from "./Native";

const PageRegistry = {};

class PageManager {
    constructor(mainElement, headerElement) {
        this.mainElement = mainElement;
        this.headerElement = headerElement;
    }

    init() {
        log('page mgr init');
        document.addEventListener("backbutton", () => this.backButton(), false);
    }

    backButton() {
        let page = PageRegistry[this.currentPage];
        log('back button for ' + this.currentPage);

        if(!dfn(page)) {
            return;
        }

        if(!dfn(page.meta.back)) {
            return;
        }

        this.gotoPage(page.meta.back);

    }

    addPage(name, page, meta, override=false) {
        if(dfn(PageRegistry[name]) && !override) {
            log('cannot override existing page ' + name);
            return;
        }

        PageRegistry[name] = {
            inst : page,
            meta : meta,
            name : name
        };

        page.element = this.mainElement;
    }

    gotoPage(name) {
        let page = PageRegistry[name];

        if(!dfn(page)) {
            log('no page of name ' + name + ' exists');
            return;
        }

        log('navigating to ' + name);
        log(page);

        // this.renderHeader(page);

        // clear out existing content
        $(this.mainElement).empty();

        // add the page content
        page.inst.render();

        this.initPhoneDefaults();

        this.currentPage = name;
    }

    initPhoneDefaults() {
        $("input[type='text'], input[type='number'], input[type='password']").change(() => {
            Native.hideKeyboard();
        });
    }

    renderHeader(page) {
        if(dfn(page.meta.title)) {
            $(this.headerElement).find('h1').text(page.meta.title);
        } else {
            $(this.headerElement).find('h1').text('');
        }

        // if(dfn(page.meta.back)) {
        //     let backLink = $(this.headerElement).find('a');
        //     backLink.removeClass('hidden');
        //     backLink.attr('data-back', page.meta.back);
        //
        //     $('[data-back]').click((e) => {
        //         log('back click');
        //         this.gotoPage($(e.currentTarget).attr('data-back'));
        //     });
        // } else {
        //     $(this.headerElement).find('a').addClass('hidden');
        // }
    }
}

export default PageManager;