import DemoPage from "./pages/DemoPage";

require('../../node_modules/bootstrap/dist/js/bootstrap.min');
require('../../node_modules/bootstrap-select/dist/js/bootstrap-select.min');

import {log} from "./common/Logging";

import App from "./app/App";
import PageManager from "./common/PageManager";
import DemoView from "./views/DemoView";
import TopUpView from "./views/TopUpView";

import DemoModel from "./models/DemoModel";
import UpdatingTopUpView from "./views/UpdatingTopUpView";
import BalanceView from "./views/BalanceView";
import HomePage from "./pages/HomePage";
import ShopDemoPage from "./pages/ShopDemoPage";
import ActivityPage from "./pages/ActivityPage";
import ActityItemPage from "./pages/ActityItemPage";
import PayWithPagoPage from "./pages/PayWithPagoPage";
import PayWithPagoUpdatePage from "./pages/PayWithPagoUpdatePage";
import LoginView from "./views/LoginView";
import UserModel from "./models/UserModel";
import TopUpModel from "./models/TopUpModel";
import RegsiterView from "./pages/RegsiterView";
import ProfileImageEditPage from "./pages/ProfileImageEditPage";

const deviceReady = () => {
    log('we are DEVICE ready...');

    const pageManager = new PageManager('#id_mainContent', '#id_header');
    pageManager.init();

    const demoModel = new DemoModel();
    demoModel.incrementBalance(10);

    const userModel = new UserModel();
    const topUpModel = new TopUpModel();

    pageManager.addPage('loginPage', new LoginView(userModel), { title : 'Login' });
    pageManager.addPage('registerPage', new RegsiterView(userModel), { title : 'Register', back : 'loginPage'});
    pageManager.addPage('shopDemoPage', new ShopDemoPage(), { back : 'demoPage'});
    pageManager.addPage('homePage', new HomePage(userModel, topUpModel), { title : 'Pago', back : 'demoPage' });
    pageManager.addPage('profileEditPage', new ProfileImageEditPage(userModel), { title : 'Profile', back : 'homePage' });
    pageManager.addPage('activity', new ActivityPage(userModel), { title : 'Activity', back : 'homePage' });
    pageManager.addPage('activityItem', new ActityItemPage(demoModel), { title : 'Activity', back : 'activity' });
    pageManager.addPage('payWithPago', new PayWithPagoPage(demoModel), { title : 'Checkout With Pago', back : 'shopDemoPage' });
    pageManager.addPage('payWithPagoUpdate', new PayWithPagoUpdatePage(demoModel), { });
    pageManager.addPage('topUp', new TopUpView(topUpModel, userModel), { title : 'Top Up', back : 'homePage' });
    pageManager.addPage('updatingTopUp', new UpdatingTopUpView(userModel), { title : 'Updating Balance' });
    pageManager.addPage('balance', new BalanceView(demoModel), { title : 'Balance', back : 'demoPage' });

    App.pageMgr = pageManager;

    pageManager.gotoPage('loginPage');
};

$(document).ready(() => {
    log('ready....');

    if(App.web) {
        deviceReady();
    } else {
        document.addEventListener('deviceready', deviceReady, false);
    }
});