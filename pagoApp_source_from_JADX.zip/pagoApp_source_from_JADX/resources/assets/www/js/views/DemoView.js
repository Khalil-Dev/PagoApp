import View from "../common/View";
import { demoTemplate } from "./templates/DemoTemplate";
import App from "../app/App";
import {log} from "../common/Logging";

class DemoView extends View {
    constructor(element, model) {
        super(element, model);
    }

    render() {
        $(this.element).append(demoTemplate());
        this.initialiseEvents();
    }

    initialiseEvents() {
        $('#id_topUpBtn').click(() => {
            App.pageMgr.gotoPage('topUp');
        });

        $('#id_viewBalance').click(() => {
            App.pageMgr.gotoPage('balance');
        });
    }
}

export default DemoView;