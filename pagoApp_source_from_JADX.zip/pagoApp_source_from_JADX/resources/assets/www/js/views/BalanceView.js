import View from "../common/View";

import App from "../app/App";
import {log} from "../common/Logging";
import {balanceTemplate} from "./templates/BalanceTemplate";

class BalanceView extends View {
    constructor(model) {
        super(null, model);
    }

    render() {
        $(this.element).append(balanceTemplate());
    }

    initialiseEvents() {
    }
}

export default BalanceView;