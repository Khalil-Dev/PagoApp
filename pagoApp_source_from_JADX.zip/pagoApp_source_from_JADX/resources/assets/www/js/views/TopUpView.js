import View from "../common/View";
import App from "../app/App";
import {log} from "../common/Logging";
import {topUpTemplate} from "./templates/TopUpTemplate";
import {dfn} from "../common/Utils";
import UserProfileImage from "../common/UserProfileImage";

class TopUpView extends View {
    constructor(topUpModel, userModel) {
        super(null, {
            topUpModel : topUpModel,
            userModel : userModel
        });

        this.userProfileImageMgr = new UserProfileImage();
        this.userProfileImageMgr.on('userProfileImage', (result) => {
            log("we have profile");
            log("img len " + result.md5);
            if(result.img === 'NONE') {
                return;
            }

            $('#id_profileImg').attr('src', "data:image/jpeg;base64," + result.img);
        });
    }

    render() {
        $(this.element).append(topUpTemplate(App.getUser()));

        this.userProfileImageMgr.loadProfileImage(App.getUser().id);

        $('.selectpicker').selectpicker('refresh');
        this.initialiseEvents();
    }

    initialiseEvents() {
        $('#id_topUpBtn').click(() => {

            let carrier = $('.cl_selectedCarrier').attr('data-carrierName');
            if(!dfn(carrier)) {
                alert('You must select a carrier');
                return;
            }

            this.model.topUpModel.topUp(App.getUserPhone(), $('#id_topUpVoucher').val(), carrier);

            App.pageMgr.gotoPage('updatingTopUp');
        });

        $('.cl_carrierSelectDiv').click((e) => {
            $('.cl_carrierSelectDiv .cl_circle').removeClass('cl_selectedCarrier');
            $(e.currentTarget).find('.cl_circle').addClass('cl_selectedCarrier');
        });
    }
}

export default TopUpView;