const balanceTemplate = () => {
    return `
        <div class="container-fluid">
            <div style="text-align: center" id="id_balance">
                <span>Your balance is currently</span>
            </div>
            
            <div style="text-align: center; margin-top: 20px; margin-bottom: 20px; font-size: 18px; font-weight: bold" id="id_balance">
                <span>$128</span>
            </div>
            
            <div style="text-align: center" id="id_balance">
                <span>Last updated 13:42 19th Jan 2018 by $30</span>
            </div>
        </div>
        
`;
}

export { balanceTemplate };