const updatingTopUpTemplate = (user) => {
    let imgName = (user.firstName + user.lastName).toLowerCase();

    return `
    <div class="container-fluid" id="id_topupLoadingDiv">
        <div style="margin-top: 10px; font-size: 18px" class="cl_centered">
            Recharge
        </div>
        <div id="id_loader">
        </div>
    
        <div style="text-align: center; font-size: 16px">
            <span id="id_updateStatus" style="text-align: center; top: 50%; position: absolute; left: 0px;width: 100%;"></span> 
        </div>
    </div>
    `;
};

export { updatingTopUpTemplate };