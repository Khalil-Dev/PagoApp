const topUpTemplate = (user) => {
    let imgName = (user.firstName + user.lastName).toLowerCase();

    return `
    <div class="container-fluid">
        <div id="id_profileImgDiv">
            <div class="cl_centered">
                <img class="cl_avatarFrame" src="img/dummy-avatar.png" id="id_profileImg">
            </div>
            <div class="cl_centered" id="id_countryFlag">
                <img src="img/flags/${user.country}.png">
            </div>
            <div id="id_homePageUserName">
                <span>${user.firstName} ${user.lastName}</span>
            </div>
        </div>
        <hr />
        <div style="margin-top: 5px" class="cl_centered">
            Want to recharge? Enter airtime voucher number below
        </div>
        <div style="margin-top: 5px">
            <input type="text" class="cl_fullWidthCtrl cl_centered" id="id_topUpVoucher"/> 
        </div>
        <div style="margin-top: 5px" class="cl_centered">
            Select your network provider
        </div>
        <div class="container-fluid" style="margin-top: 5px">
            <div class="row cl_carrierSelectDiv">
                <div class="pull-left">
                    <img src="img/carriers/mtn.png" />
                    <span>MTN</span>
                </div>
                <div class="pull-right cl_circle" data-carrierName="MTN">
                </div>
            </div>
            <div class="row cl_carrierSelectDiv">
                <div class="pull-left">
                    <img src="img/carriers/cellc.png" />
                    <span>Cell C</span>
                </div>
                <div class="pull-right cl_circle" data-carrierName="Cell C">
                </div>
            </div>
            <div class="row cl_carrierSelectDiv">
                <div class="pull-left">
                    <img src="img/carriers/telkom.png" />
                    <span>Telkom</span>
                </div>
                <div class="pull-right cl_circle" data-carrierName="Telkom">
                </div>
            </div>
            <div class="row cl_carrierSelectDiv">
                <div class="pull-left">
                    <img src="img/carriers/vodacom.png" data-carrierName="Vodacom"/>
                    <span>Vodacom</span>
                </div>
                <div class="pull-right cl_circle">
                </div>
            </div>
        </div>
        <div style="margin-top: 5px">
            <button class="btn btn-primary cl_fullWidthCtrl" id="id_topUpBtn">Recharge</button>
        </div>
    </div>
    `;
};

export { topUpTemplate };