const demoTemplate = () => {
    return `
        <div class="container-fluid">
            <div>
                <button class="btn btn-default cl_fullWidthCtrl" id="id_topUpBtn">Top Up</button>
            </div>
            <div>
                <button class="btn btn-default cl_fullWidthCtrl" id="id_viewBalance">View Balance</button>
            </div>
            <div>
                <button class="btn btn-default cl_fullWidthCtrl" id="id_payWithPago">Pay With Pago</button>
            </div>
        </div>
        
`;
}

export { demoTemplate };