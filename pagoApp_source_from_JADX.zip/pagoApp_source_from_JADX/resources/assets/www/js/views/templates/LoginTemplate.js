const LoginTemplate = () => {
    return `
    <div class="container-fluid">
            <div  style="text-align: center" >
                <img src="img/new/logo.png" style="width: 50%; margin-top: 30px; margin-bottom: 50px" />
            </div>
            
            <div class="cl_shadow" style="display: flex; flex-direction: row; margin-bottom: 25px; padding: 5px">
                <img src="img/new/userIcon.png" />
                <input type="tel" id="id_phoneNumber" placeholder="Phone Number" style="flex: 1" autocomplete="off"/>
            </div>
            
            <div class="cl_shadow" style="display: flex; flex-direction: row; margin-bottom: 25px; padding: 5px">
                <img src="img/new/lockIcon.png" />
                <input type="password" id="id_password" placeholder="Password" style="flex: 1" autocomplete="off" autocomplete="new-password"/>
            </div>
            
            <div style="text-align: center; margin-top: 20px; margin-bottom: 20px; font-size: 18px; font-weight: bold">
                <button class="btn btn-primary cl_fullWidthCtrl cl_orangeBtn" id="id_loginInBtn">Sign In</button>
            </div>
            
            <div style="text-align: center; margin-top: 20px; margin-bottom: 20px; font-size: 18px; font-weight: bold">
                <span style="color: #9497A5; font-size: 14px">OR</span>
            </div>
            
            <div style="margin-top: 20px">
                <button class="btn btn-primary cl_fullWidthCtrl cl_greyBtn" id="id_registerLink">Sign Up</button>
                <!--<span>Don't have an account? <a href="#" id="id_registerLink">Click here to register</a></span>-->
            </div>
        </div>
    `;
};

export { LoginTemplate };