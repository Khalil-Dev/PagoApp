import {LoginTemplate} from "./templates/LoginTemplate";
import View from "../common/View";
import {log} from "../common/Logging";
import App from "../app/App";
import {SpinnerOff, SpinnerOn} from "../common/CordovaHelper";

class LoginView extends View {
    constructor(userModel) {
        super(null, userModel);
    }

    attachToModel() {
        this.model.clearEvent('userLogin');
        this.model.on('userLogin', (result) => {
            SpinnerOff();
            log(result);

            if(!result.success)  {
                alert('Login failed');
                return;
            }

            App.setUserPhone($('#id_phoneNumber').val());

            App.pageMgr.gotoPage('homePage');
        });
    }

    render() {
        this.attachToModel();

        $(this.element).append(LoginTemplate());

        $('#id_loginInBtn').click(() => {
            SpinnerOn("Logging in...");
            this.model.logIn($('#id_phoneNumber').val(), $('#id_password').val());
        });

        $('#id_registerLink').click(() => {
           App.pageMgr.gotoPage('registerPage');
        });
    }
}

export default LoginView;