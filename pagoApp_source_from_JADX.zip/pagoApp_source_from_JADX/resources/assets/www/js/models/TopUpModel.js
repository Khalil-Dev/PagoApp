import Model from "../common/Model";
import Net from "../common/Net";
import App from "../app/App";

class TopUpModel extends Model {
    constructor() {
        super('TopUpModel');
    }

    topUp(phoneNumber, voucher, carrier) {
        Net.post(`${App.root}/user/updateBalanceWithVoucher?phoneNumber=${phoneNumber}&voucher=${voucher}&carrierName=${carrier}`, {}, (result) => {
            this.fire('topUp', result);
        }, Net.ERR);
    }
}

export default TopUpModel;