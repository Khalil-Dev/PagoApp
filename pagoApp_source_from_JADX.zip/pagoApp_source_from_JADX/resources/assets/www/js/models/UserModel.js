import Model from "../common/Model";
import App from "../app/App";
import Net from "../common/Net";
import {log} from "../common/Logging";

class UserModel extends Model {
    constructor() {
        super('UserModel');
    }

    logIn(phone, password) {
        Net.post(`${App.root}/user/login?phoneNumber=${phone}&password=${password}`, {}, (result) => {
            this.fire('userLogin', result);
        }, Net.ERR);
    }

    getUser(phone) {
        Net.get(`${App.root}/user/getUser?phoneNumber=${phone}`, (result) => {
            this.fire('getUser', result);
        }, Net.ERR);
    }

    getTransactions(userId) {
        Net.get(`${App.root}/user/getTransactions?userId=${userId}`, (result) => {
            log(result);
            this.fire('usersTransactions', result);
        }, Net.ERR);
    }

    registerUser(phone, email, firstName, lastName, pass, country) {
        Net.post(`${App.root}/user/register`, {
            phone : phone,
            email : email,
            pass : pass,
            firstName : firstName,
            lastName : lastName,
            country : country
        }, (result) => {
            log(result);
            this.fire('userRegister', result);
        }, Net.ERR);
    }

    getUserProfile(userId) {
        Net.get(`${App.root}/user/userImg/${userId}`, (result) => {
            log('get user profile has returned');
            this.fire('userProfileImage', result);
        }, Net.ERR);
    }

    saveUserProfileImage(userId, img) {
        Net.post(`${App.root}/user/userImg`, {
            userId : userId,
            img : img
        }, (result) => {
            this.fire('saveUserProfileImage', result);
        }, Net.ERR);
    }

    getUserProfileMD5(userId) {
        Net.get(`${App.root}/user/userImg/${userId}/md5`, (result) => this.fire('getUserProfileMD5', result), Net.ERR);
    }

}

export default UserModel;