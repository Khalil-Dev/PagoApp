import Model from "../common/Model";

class DemoModel extends Model {
    constructor() {
        super("DemoModel");

        this.data = {
            balance : 0
        }
    }

    incrementBalance(amount) {
        this.data.balance += amount;
    }

    decrementBalance(amount) {
        this.data.balance -= amount;
    }
}

export default DemoModel;