import View from "../common/View";
import {ActivityItemPageTemplate} from "./templates/ActivityItemPageTemplate";
import App from "../app/App";

class ActityItemPage extends View {
    constructor(model) {
        super(null, model);
    }

    render() {
        $(this.element).append(ActivityItemPageTemplate(App.getTx(), App.getUser()));

        this.initialiseEvents();
    }

    initialiseEvents() {

    }
}

export default ActityItemPage;