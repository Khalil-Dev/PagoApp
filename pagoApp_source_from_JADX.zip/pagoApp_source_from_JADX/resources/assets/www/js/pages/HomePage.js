import View from "../common/View";
import {HomePageTemplate} from "./templates/HomePageTemplate";
import App from "../app/App";
import {log} from "../common/Logging";
import {SpinnerOff, SpinnerOn} from "../common/CordovaHelper";
import UserProfileImage from "../common/UserProfileImage";
import {dfn} from "../common/Utils";

class HomePage extends View {
    constructor(userModel, topUpModel) {
        super(null, {
            userModel : userModel,
            topUpModel : topUpModel
        });

        this.model.userModel.on('getUser', (user) => {
            SpinnerOff();
            log(user);

            App.setUser(user);

            $(this.element).append(HomePageTemplate(user));

            log('get user profile...');
            this.userProfileImageMgr.loadProfileImage(user.id, true);

            this.initialiseEvents();
        });

        this.userProfileImageMgr = new UserProfileImage();
        this.userProfileImageMgr.on('userProfileImage', (result) => {
            log("we have profile");
            log("img len " + result.img.length);
            if(result.img === 'NONE') {
                return;
            }

            $('#id_profileImg').attr('src', "data:image/jpeg;base64," + result.img);
        });
    }

    render() {
        SpinnerOn("Loading...");
        this.model.userModel.getUser(App.getUserPhone());
    }

    initialiseEvents() {
        // $('#id_topUpBtn').click(() => {
        //     App.pageMgr.gotoPage('topUp');
        // });

        $('#id_viewActivityBtn').click(() => {
            log('activity click');
            App.pageMgr.gotoPage('activity');
        });

        $('#id_profileImgDiv').click(() => {
            App.pageMgr.gotoPage('profileEditPage');
        });

        $('.cl_carrierSelectDiv').click((e) => {
            $('.cl_carrierSelectDiv .cl_circle').removeClass('cl_selectedCarrier');
            $(e.currentTarget).find('.cl_circle').addClass('cl_selectedCarrier');
        });

        $('#id_topUpBtn').click(() => {

            let carrier = $('.cl_selectedCarrier').attr('data-carrierName');
            if(!dfn(carrier)) {
                alert('You must select a carrier');
                return;
            }

            this.model.topUpModel.topUp(App.getUserPhone(), $('#id_topUpVoucher').val(), carrier);

            App.pageMgr.gotoPage('updatingTopUp');
        });
    }
}

export default HomePage;