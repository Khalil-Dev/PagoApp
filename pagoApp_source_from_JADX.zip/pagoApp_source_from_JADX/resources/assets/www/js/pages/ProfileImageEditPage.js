import View from "../common/View";
import {log} from "../common/Logging";
import {ProfileImageEditPageTemplate} from "./templates/ProfileImageEditPageTemplate";
import {getPicture, SpinnerOff, SpinnerOn} from "../common/CordovaHelper";
import App from "../app/App";
import UserProfileImage from "../common/UserProfileImage";

class ProfileImageEditPage extends View {
    constructor(userModel) {
        super(null, userModel);

        this.userProfileImageMgr = new UserProfileImage();
        this.userProfileImageMgr.on('userProfileImage', (result) => {
            log("we have profile");
            log(result);

            if(result.img === 'NONE') {
                return;
            }

            $('#id_profileImg').attr('src', "data:image/jpeg;base64," + result.img);
        });
    }

    attachModel() {
        this.model.on('saveUserProfileImage', (result) => {
            SpinnerOff();
            log('saved image');
            log(result);

            App.setUserImage(result);
        })
    }

    render() {
        this.attachModel();
        $(this.element).append(ProfileImageEditPageTemplate);
        this.userProfileImageMgr.loadProfileImage(App.getUser().id);

        $('#id_getPicBtn').click(() => {
            getPicture((result) => {
                log('received image data');

                this.selectedImage = result;

                $('#id_profileImg').attr('src', "data:image/jpeg;base64," + result);

                $('#id_saveProfileImg').removeClass('hidden');
            }, () => {

            });
        });

        $('#id_saveProfileImg button').click(() => {
            $('#id_saveProfileImg button').addClass('hidden');
            SpinnerOn("Saving...");
            this.model.saveUserProfileImage(App.getUser().id, this.selectedImage);
        })
    }
}

export default ProfileImageEditPage;