import View from "../common/View";
import {DemoPageTemplate} from "./templates/DemoPageTemplate";
import App from "../app/App";

class DemoPage extends View {
    constructor(model) {
        super(null, model);
    }

    render() {
        $(this.element).append(DemoPageTemplate());

        this.initialiseEvents();
    }

    initialiseEvents() {
        $('#id_userInterfaceBtn').click(() => {
            // App.pageMgr.gotoPage('homePage');
            App.pageMgr.gotoPage('loginPage');
        });

        $('#id_shopWithPagoBtn').click(() => {
            App.pageMgr.gotoPage('shopDemoPage');
        });
    }
}

export default DemoPage;