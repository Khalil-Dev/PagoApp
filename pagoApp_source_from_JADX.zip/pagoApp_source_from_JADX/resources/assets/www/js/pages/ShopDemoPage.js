import View from "../common/View";
import {ShopDemoPageTemplate} from "./templates/ShopDemoPageTemplate";
import App from "../app/App";

class ShopDemoPage extends View {
    constructor(model) {
        super(null, model);
    }

    render() {
        $(this.element).append(ShopDemoPageTemplate());

        this.initialiseEvents();
    }

    initialiseEvents() {
        $('.cl_payWithPago').click(() => {
            App.pageMgr.gotoPage('payWithPago');
        });
    }
}

export default ShopDemoPage;