import View from "../common/View";
import {ActivityPageTemplate} from "./templates/ActivityPageTemplate";
import App from "../app/App";
import {SpinnerOff, SpinnerOn} from "../common/CordovaHelper";

class ActivityPage extends View {
    constructor(model) {
        super(null, model);

        this.model.on('usersTransactions', (txs) => {
            SpinnerOff();

            this.txs = txs;
            $(this.element).append(ActivityPageTemplate(txs));

            this.initialiseEvents();
        });
    }

    render() {
        SpinnerOn();
        this.model.getTransactions(App.getUser().id);
    }

    initialiseEvents() {
        $('.cl_activityItemDiv').click((e) => {
            let i = $(e.currentTarget).attr('data-txIdx');

            App.setTx(this.txs[i]);

            App.pageMgr.gotoPage('activityItem');
        });
    }
}

export default ActivityPage;