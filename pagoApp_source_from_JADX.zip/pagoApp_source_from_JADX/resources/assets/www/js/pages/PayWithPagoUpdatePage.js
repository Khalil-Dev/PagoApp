import View from "../common/View";
import App from "../app/App";
import {log} from "../common/Logging";
import {payWithPagoUpdatePageTemplate} from "./templates/PayWithPagoUpdatePageTemplate";


class PayWithPagoUpdatePage extends View {
    constructor(model) {
        super(null, model);
    }

    render() {
        $(this.element).append(payWithPagoUpdatePageTemplate());
        this.initialiseEvents();
    }

    initialiseEvents() {
        $('#id_updateStatus').text('Contacting Pago...');

        $('#id_continueShopping').click(() => {
            App.pageMgr.gotoPage('shopDemoPage');
        });

        $('#id_viewBalance').click(() => {
            App.pageMgr.gotoPage('balance');
        });

        setTimeout(() => this.showConnectionStatus(), 2000);
    }

    showConnectionStatus() {
        $('#id_updateStatus').text('Processing Payment...');

        log('updated...');
        setTimeout(() => this.done(), 3000);
    }

    done() {
        log('updated...');
        $('#id_updatingGif').addClass('hidden');
        $('#id_paidAmountDiv').removeClass('hidden');
        $('#id_updateStatus').css('font-weight', 'bold');
        $('#id_updateStatus').text('Your payment was successful!');
    }

}

export default PayWithPagoUpdatePage;