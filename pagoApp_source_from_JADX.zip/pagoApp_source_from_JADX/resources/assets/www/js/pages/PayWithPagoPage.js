import View from "../common/View";
import {PayWithPagoPageTemplate} from "./templates/PayWithPagoPageTemplate";
import App from "../app/App";

class PayWithPagoPage extends View {
    constructor(model) {
        super(null, model);
    }

    render() {
        $(this.element).append(PayWithPagoPageTemplate());

        this.initialiseEvents();
    }

    initialiseEvents() {
        $('#id_checkoutBtn').click(() => {
            App.pageMgr.gotoPage('payWithPagoUpdate');
        });
    }
}

export default PayWithPagoPage;