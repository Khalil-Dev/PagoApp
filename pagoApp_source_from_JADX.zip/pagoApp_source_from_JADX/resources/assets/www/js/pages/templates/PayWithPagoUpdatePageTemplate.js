const payWithPagoUpdatePageTemplate = () => {
    return `
    <div class="container-fluid">
        <div id="id_profileImgDiv">
            <div class="cl_centered">
                <img class="cl_avatarFrame" src="img/philip.png">
            </div>
            <div class="cl_centered" id="id_countryFlag">
                <img src="img/saFlag.png">
            </div>
            <div id="id_homePageUserName">
                <span>Philip Mngadi</span>
            </div>
        </div>
        
        <div style="text-align: center" id="id_updatingGif">
            <img class="cl_loadingImg cl_fullWidthCtrl" src="./img/loading.gif"> 
        </div>
        <div style="text-align: center; font-size: 16px">
            <span id="id_updateStatus"></span> 
        </div>
        <div class="hidden" id="id_paidAmountDiv" style="text-align: center; margin-top: 10px">
            <div style="font-size: 16px">
                <span style="color: darkgreen">-ZAR 2065.00</span> has been debited from your Pago account.
            </div>
            <div style="margin-top: 10px">
                <button class="btn btn-primary cl_fullWidthCtrl" id="id_continueShopping">Continue Shopping</button>
            </div>
        </div>
    </div>
    `;
};

export { payWithPagoUpdatePageTemplate };