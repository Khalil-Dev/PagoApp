import {GetCountriesSelect} from "../../common/Countries";

const RegisterMainInfoTemplate = `
    <div class="container-fluid" id="id_registerContainerDiv">
        <div class="cl_centered">
            <input type="tel" class="cl_fullWidthCtrl" id="id_phNumber" placeholder="Phone Number"/>
        </div>
        <div class="cl_centered">
            <input type="email" class="cl_fullWidthCtrl" id="id_email" placeholder="Email"/>
        </div>
        <div class="cl_centered">
            <input type="text" class="cl_fullWidthCtrl" id="id_firstName" placeholder="First Name"/>
        </div>
        <div class="cl_centered">
            <input type="text" class="cl_fullWidthCtrl" id="id_lastName"  placeholder="Last Name"/>
        </div>
        <div class="cl_centered">
            <input type="password" class="cl_fullWidthCtrl" id="id_pass1" placeholder="Password"/>
        </div>
        <div class="cl_centered">
            <input type="password" class="cl_fullWidthCtrl" id="id_pass2" placeholder="Repeat Password"/>
        </div>
        <div class="cl_centered" >
            <select class="cl_fullWidthCtrl" id="id_country">
                <option value="-1">Select your country...</option>
                ${GetCountriesSelect()}
            </select>
            
        </div>
        
        <div style="text-align: center; margin-top: 20px; margin-bottom: 20px; font-size: 18px; font-weight: bold">
            <button class="btn btn-primary cl_fullWidthCtrl cl_orangeBtn" id="id_registerBtn">Register</button>
        </div>
    </div>
`;

export default RegisterMainInfoTemplate;