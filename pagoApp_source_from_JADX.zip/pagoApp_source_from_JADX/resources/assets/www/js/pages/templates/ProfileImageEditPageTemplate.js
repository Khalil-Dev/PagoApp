export const ProfileImageEditPageTemplate = `
    <div class='container-fluid' style="padding: 10px">
        <div class="row" style="text-align: center">
            <img id="id_profileImg" class="cl_avatarFrame" src="img/dummy-avatar.png"/>
        </div>
        <div class="row cl_centered">
            <button class="cl_fullWidthCtrl btn-default btn" id="id_getPicBtn">Take Picture</button>
        </div>
        <div class="row cl_centered hidden" id="id_saveProfileImg">
            <button class="cl_fullWidthCtrl btn-default btn">Save Profile Picture</button>
        </div>
    </div>
`;