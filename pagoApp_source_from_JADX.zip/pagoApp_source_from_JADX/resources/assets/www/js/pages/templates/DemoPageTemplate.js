export const DemoPageTemplate = (data) => {
    return `
    <div class="container-fluid">
        <div style="text-align: center">
            <img src="img/logo.png" />
        </div>
        <div>
            <button class="btn btn-primary cl_fullWidthCtrl cl_orangeBtn" id="id_userInterfaceBtn">User Interface</button>
        </div>
        <div>
            <button class="btn btn-primary cl_fullWidthCtrl cl_orangeBtn" id="id_shopWithPagoBtn">Shop with Pago</button>
        </div>
    </div>
    `;
};