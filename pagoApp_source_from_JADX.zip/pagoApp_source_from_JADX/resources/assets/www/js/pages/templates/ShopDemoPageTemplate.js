export const ShopDemoPageTemplate = (data) => {
    return `
    <div class="container-fluid">
        <div>
            <img src="img/shopDemo/amazon.jpeg" style="height: 90px"/>
        </div>
        
        <div class="container-fluid" style="margin: 5px; border: 1px solid lightgrey; padding: 5px">
            <div class="container-fluid">
                <div class="pull-left" style="width: 30%">
                    <img src="img/shopDemo/trainers.jpg" style="width: 90%"/>
                </div>
                <div class="pull-right" style="width: 70%;">
                    <div style="font-weight: bold">Nike Men's Air Max 90 Essential Sneakers</div>
                    <div style="color: #4cae4c">ZAR 65.00</div>
                </div>
            </div>
            <div class="container-fluid">
                <div style="text-align: center">
                    <button class="btn btn-sm btn-default" style="width: 30%;"><img src="img/pay/visa.png" style="width: 100%; height: 20px"/></button>
                    <button class="btn btn-sm btn-default" style="width: 30%;"><img src="img/pay/paypal.png" style="width: 100%; height: 20px"/></button>
                    <button class="btn btn-sm btn-default cl_payWithPago" style="width: 30%;"><img src="img/pay/pago.png" style="width: 100%; height: 20px"/></button>
                </div>
            </div>
        </div>
        
        <div class="container-fluid" style="margin: 5px; border: 1px solid lightgrey; padding: 5px">
            <div class="container-fluid">
                <div class="pull-left" style="width: 30%">
                    <img src="img/shopDemo/shoe.jpg" style="width: 90%"/>
                </div>
                <div class="pull-right" style="width: 70%;">
                    <div style="font-weight: bold">Nike Men's Court Royale Suede Sneakers</div>
                    <div style="color: #4cae4c">ZAR 80.00</div>
                </div>
            </div>
            <div class="container-fluid">
                <div style="text-align: center">
                    <button class="btn btn-sm btn-default" style="width: 30%;"><img src="img/pay/visa.png" style="width: 100%; height: 20px"/></button>
                    <button class="btn btn-sm btn-default" style="width: 30%;"><img src="img/pay/paypal.png" style="width: 100%; height: 20px"/></button>
                    <button class="btn btn-sm btn-default cl_payWithPago" style="width: 30%;"><img src="img/pay/pago.png" style="width: 100%; height: 20px"/></button>
                </div>
            </div>
        </div>
        
        <div class="container-fluid" style="margin: 5px; border: 1px solid lightgrey; padding: 5px">
            <div class="container-fluid">
                <div class="pull-left" style="width: 30%">
                    <img src="img/shopDemo/trainers2.jpg" style="width: 90%"/>
                </div>
                <div class="pull-right" style="width: 70%;">
                    <div style="font-weight: bold">Nike Men's T-Lite XI Cross Trainers</div>
                    <div style="color: #4cae4c">ZAR 45.00</div>
                </div>
            </div>
            <div class="container-fluid">
                <div style="text-align: center">
                    <button class="btn btn-sm btn-default" style="width: 30%;"><img src="img/pay/visa.png" style="width: 100%; height: 20px"/></button>
                    <button class="btn btn-sm btn-default" style="width: 30%;"><img src="img/pay/paypal.png" style="width: 100%; height: 20px"/></button>
                    <button class="btn btn-sm btn-default cl_payWithPago" style="width: 30%;"><img src="img/pay/pago.png" style="width: 100%; height: 20px"/></button>
                </div>
            </div>
        </div>
        
    </div>
    `;
};