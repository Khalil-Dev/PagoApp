import {getShortMonth} from "../../common/Utils";

export const ActivityItemPageTemplate = (data, user) => {

    let s1 = '';
    let s2 = '';
    let s3 = '';
    let s4 = '';
    let s5 = '';

    if(data.type === 'merchantPurchase') {
        s1 = `<span>You paid ZAR ${parseFloat(data.amount).toFixed(2)} to ${data.merchantName}</span>`;
        s2 = 'PURCHASE TOTAL';
        s3 = data.merchantName;
        s4 = `-ZAR ${parseFloat(data.amount).toFixed(2)}`;
        s5 = data.merchantTransactionId;
    } else {
        s1 = `<span>You topped up ZAR ${parseFloat(data.amount).toFixed(2)} to ${data.carrierName}</span>`;
        s2 = 'TOP UP TOTAL';
        s3 = data.carrierName;
        s4 = `+ZAR ${parseFloat(data.amount).toFixed(2)}`;
        s5 = data.voucherCode;
    }
    
    return `
    <div class="container-fluid">
        <div class="container-fluid" style="background-color: rgb(251, 206, 131); border-bottom: solid 2px rgb(255, 128, 13); margin-bottom: 10px">
            <div>
                <span style="color: rgb(255, 128, 13);">${data.time.day} ${getShortMonth(data.time.month)} ${data.time.year}</span>
            </div>
            <div style="text-align: center; margin-top: 10px; margin-bottom: 10px">
                ${s1}
            </div>
        </div>
        
        <div style="margin-top: 10px">
            <div>
                <span style="font-weight: bold; font-size: 16px">Successful Purchase</span>
            </div>
            <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
                <div class="pull-left">
                    ${user.email}
                </div>
                <div class="pull-right">
                    ZAR ${parseFloat(data.amount).toFixed(2)}
                </div>
            </div>
        </div>
        
        <hr />
        
        <div style="margin-top: 5px">
            <div>
                <span style="font-weight: bold; font-size: 16px">Purchase Details</span>
            </div>
            
            <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
                <div class="pull-left" style="color: rgb(255, 128, 13); font-weight: bold">
                    ${s5}
                </div>
                <div class="pull-right" style="color: rgb(255, 128, 13); font-weight: bold">
                    ZAR ${parseFloat(data.amount).toFixed(2)}
                </div>
            </div>
            
            <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
                <div class="pull-left">
                    Amount
                </div>
                <div class="pull-right">
                    ZAR ${parseFloat(data.amount).toFixed(2)}
                </div>
            </div>
            
            <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
                <div class="pull-left">
                    Shipping
                </div>
                <div class="pull-right">
                    ZAR 0.00
                </div>
            </div>
            
            <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
                <div class="pull-left">
                    Tax
                </div>
                <div class="pull-right">
                    ZAR 0.00
                </div>
            </div>
            
            <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
                <div class="pull-left">
                    PURCHASE TOTAL
                </div>
                <div class="pull-right">
                    ZAR ${parseFloat(data.amount).toFixed(2)}
                </div>
            </div>
            
            <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
                <div class="pull-left">
                    FEE
                </div>
                <div class="pull-right">
                    ZAR 0.00
                </div>
            </div>
            
        </div>
        
        <hr />
        
        <div class="container-fluid cl_activityItemDiv">
            <div class="row">
                <div class="pull-left" style="width: 20%; text-align: center; margin-top: 10px">
                    <span class="glyphicon glyphicon-ok" aria-hidden="true" style="font-size: 16px; border-radius: 50%; border: 1px solid green; padding: 5px; color: green"></span>
                </div>
                <div class="pull-left" style="width: 50%">
                    <div>
                        <span style="font-weight: bold; font-size: 16px">${s3}</span>
                    </div>
                    <div>
                        <span>Payment Successful</span>
                    </div>
                </div>
                <div class="pull-right" style="width: 30%">
                    <span style="font-size: 16px">${s4}</span>
                </div>
            </div>
        </div>
        
        <hr />
        
        <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
            <div class="pull-left">
                Contact
            </div>
            <div class="pull-right">
                info@pago.com
            </div>
        </div>
        <div class="container-fluid cl_containerFluidNoPadding" style="margin-top: 5px">
            <div class="pull-left">
                Transation ID
            </div>
            <div class="pull-right">
                ${data.id}
            </div>
        </div>
        
    </div>
    `;
};