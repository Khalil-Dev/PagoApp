export const HomePageTemplate = (data) => {
    let imgName = (data.firstName + data.lastName).toLowerCase();

    return `
    <div class="container-fluid">
        <div class="container-fluid" id="id_userDetailsDiv">
            <div class="row" style="margin-bottom: 30px">
                <div class="pull-left" style="width: 25%; padding: 5px"><span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span></div>
                <div class="pull-left" style="width: 50%; text-align: center; letter-spacing: 0.2px">User Profile</div>
                <div class="pull-left" style="width: 25%; text-align: right; padding: 5px"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span></div>
            </div>
            
            <div id="id_profileImgDiv" style="margin-bottom: 60px">
                <div class="cl_centered">
                    <img class="cl_avatarFrame" src="img/dummy-avatar.png" id="id_profileImg">
                </div>
                <div class="cl_centered" id="id_countryFlag">
                    <img src="img/flags/${data.country}.png">
                </div>
                <div id="id_homePageUserName">
                    <span>${data.firstName} ${data.lastName}</span>
                </div>
            </div>
        </div>
        
        <div class="container-fluid" style="margin-top: -30px">
            <div class="pull-left cl_infoUserDetailsInfoDiv cl_shadow">
                <div style="margin-bottom: 10px">Balance</div>
                <div id="id_balanceAmountDiv">
                    ${parseFloat(data.balance).toFixed(2)}
                    <span style="color: lightgrey; font-size: 14px">ZAR</span>
                </div>
            </div>
            <div class="pull-right cl_infoUserDetailsInfoDiv cl_shadow">
                <div style="margin-bottom: 10px">Activities</div>
                <div class="row" style="margin: 0px">
                    <div class="pull-left" style="margin-right: 10px;">11</div>
                    <div class="pull-right">
                        <a href="#" id="id_viewActivityBtn" style="font-size: 14px; color: #FE6902;">View All</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container-fluid" style="margin-top: 30px">
            <div style="margin-top: 5px; color: darkgrey">
            Want to recharge? Enter airtime voucher number below
            </div>
            <div style="margin-top: 5px" class="cl_shadow">
                <input type="text" class="cl_fullWidthCtrl" id="id_topUpVoucher" placeholder="Enter voucher number here" style="height: 40px; padding: 5px" /> 
            </div>
            <div style="margin-top: 25px; color: darkgrey">
                Select your network provider
            </div>
            <div class="container-fluid cl_shadow" style="margin-top: 5px">
                <div class="row cl_carrierSelectDiv">
                    <div class="pull-left">
                        <img src="img/carriers/mtn.png" />
                        <span>MTN</span>
                    </div>
                    <div class="pull-right cl_circle" data-carrierName="MTN">
                    </div>
                </div>
                <div class="row cl_carrierSelectDiv">
                    <div class="pull-left">
                        <img src="img/carriers/cellc.png" />
                        <span>Cell C</span>
                    </div>
                    <div class="pull-right cl_circle" data-carrierName="Cell C">
                    </div>
                </div>
                <div class="row cl_carrierSelectDiv">
                    <div class="pull-left">
                        <img src="img/carriers/telkom.png" />
                        <span>Telkom</span>
                    </div>
                    <div class="pull-right cl_circle" data-carrierName="Telkom">
                    </div>
                </div>
                <div class="row cl_carrierSelectDiv">
                    <div class="pull-left">
                        <img src="img/carriers/vodacom.png" data-carrierName="Vodacom"/>
                        <span>Vodacom</span>
                    </div>
                    <div class="pull-right cl_circle">
                    </div>
                </div>
            </div>
        </div>
        
        <div style="margin-top: 20px">
            <button class="btn btn-primary cl_fullWidthCtrl cl_orangeBtn" id="id_topUpBtn">Recharge</button> 
        </div>
    </div>
    `;

    // return `
    // <div class="container-fluid">
    //     <div class="row">
    //         <div class="pull-left" style="width: 25%">M</div>
    //         <div class="pull-left" style="width: 50%; text-align: center">User Profile</div>
    //         <div class="pull-left" style="width: 25%; text-align: right">S</div>
    //     </div>
    //
    //     <div id="id_profileImgDiv">
    //         <div class="cl_centered">
    //             <img class="cl_avatarFrame" src="img/dummy-avatar.png" id="id_profileImg">
    //         </div>
    //         <div class="cl_centered" id="id_countryFlag">
    //             <img src="img/flags/${data.country}.png">
    //         </div>
    //         <div id="id_homePageUserName">
    //             <span>${data.firstName} ${data.lastName}</span>
    //         </div>
    //     </div>
    //
    //     <hr />
    //     <div class="container-fluid">
    //         <div class="pull-left">
    //             Balance
    //         </div>
    //         <div class="pull-right" id="id_balanceAmountDiv">
    //             ZAR ${parseFloat(data.balance).toFixed(2)}
    //         </div>
    //     </div>
    //     <hr />
    //     <div class="container-fluid">
    //         <div class="pull-left">
    //             See Activity
    //         </div>
    //         <div class="pull-right">
    //             <a href="#" id="id_viewActivityBtn">View All</a>
    //         </div>
    //     </div>
    //     <hr />
    //     <div>
    //         <button class="btn btn-primary cl_fullWidthCtrl" id="id_topUpBtn">Recharge</button>
    //     </div>
    // </div>
    // `;
};