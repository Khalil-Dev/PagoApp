export const PayWithPagoPageTemplate = (data) => {
    return `
    <div class="container-fluid">
        <div>
            <div>
                <span>Account Email or Phone Number</span>
            </div>
            <div>
                <input type="text" class="cl_fullWidthCtrl" />
            </div>
        </div>
        <div style="margin-top: 10px">
            <div>
                <span>Password</span>
            </div>
            <div>
                <input type="password" class="cl_fullWidthCtrl" />
            </div>
        </div>
        <div style="text-align: center; margin-top: 10px">
            <button class="btn btn-default cl_fullWidthCtrl" id="id_checkoutBtn">Checkout With <img src="img/pay/pago.png" style="height: 20px"/></button>
        </div>
    </div>
    `;
};