import {getShortMonth} from "../../common/Utils";

export const ActivityPageTemplate = (data) => {
    let r = '<div class="container-fluid">';

    let i = 0;
    for(let tx of data) {
        let title = '';
        let amt = '';

        if(tx.type === 'topUp') {
            title = 'Top Up';
            amt  = `+ZAR ${parseFloat(tx.amount).toFixed(2)}`;
        } else {
            title = tx.merchantName;
            amt  = `-ZAR ${parseFloat(tx.amount).toFixed(2)}`;
        }


        r += `
            <div class="container-fluid">
                
                <div class="container-fluid cl_activityItemDiv" data-txIdx="${i}">
                    <div>
                    ${tx.time.day} ${getShortMonth(tx.time.month - 1)} ${tx.time.year}
                    </div>
                    <div class="row">
                        <div class="pull-left" style="width: 20%; text-align: center; margin-top: 10px">
                            <span class="glyphicon glyphicon-ok" aria-hidden="true" style="font-size: 16px; border-radius: 50%; border: 1px solid green; padding: 5px; color: green"></span>
                        </div>
                        <div class="pull-left" style="width: 50%">
                            <div>
                                <span style="font-weight: bold; font-size: 16px">${title}</span>
                            </div>
                            <div>
                                <span>Payment Successful</span>
                            </div>
                        </div>
                        <div class="pull-right" style="width: 30%">
                            <span style="font-size: 16px">${amt}</span>
                        </div>
                    </div>
                    <hr />
                </div>
             </div>
        `;

        i++;
    }

    r += '</div>';

    return r;
};