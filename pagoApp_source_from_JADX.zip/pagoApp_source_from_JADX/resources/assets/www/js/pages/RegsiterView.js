import View from "../common/View";
import RegisterMainInfoTemplate from "./templates/RegisterMainInfoTemplate";
import {SpinnerOff, SpinnerOn} from "../common/CordovaHelper";
import {log} from "../common/Logging";
import App from "../app/App";

class RegsiterView extends View {
    constructor(model) {
        super(null, model);
    }

    attachToModel() {
        this.model.clearEvent('userLogin');

        this.model.on('userLogin', (result) => {
            SpinnerOff();
            log(result);

            if(!result.success)  {
                alert('Login failed');
                return;
            }

            App.setUserPhone($('#id_phNumber').val());

            App.pageMgr.gotoPage('homePage');
        });

        this.model.on('userRegister', (result) => {
            SpinnerOff();
            if(!result.success) {
                alert(result.message);
                return;
            }

            SpinnerOn('Logging in...');
            this.model.logIn($('#id_phNumber').val(), $('#id_pass1').val());
        });
    }

    render() {
        this.attachToModel();
        $(this.element).append(RegisterMainInfoTemplate);

        // (phone, email, firstName, lastName, pass, country)
        $('#id_registerBtn').click(() => {
            SpinnerOn('Registering...');
            this.model.registerUser(
                $('#id_phNumber').val(),
                $('#id_email').val(),
                $('#id_firstName').val(),
                $('#id_lastName').val(),
                $('#id_pass1').val(),
                $('#id_country option:selected').val()
                );
        });
    }
}

export default RegsiterView;