import UserProfileImage from "../common/UserProfileImage";

const App = {
    web : true,
    pageMgr : null,
    // root : "http://localhost:8080",
    root : "https://pagoserver.herokuapp.com",

    setUserPhone : (phone) => {
        window.localStorage.setItem('userPhone', phone);
    },

    getUserPhone : () => {
        return window.localStorage.getItem('userPhone');
    },

    setUser : (user) => {
        window.localStorage.setItem('user', JSON.stringify(user));
    },

    getUser : () => {
        return JSON.parse(window.localStorage.getItem('user'));
    },

    setTx : (tx) => {
        window.localStorage.setItem('tx', JSON.stringify(tx));
    },

    getTx : () => {
        return JSON.parse(window.localStorage.getItem('tx'));
    },

    setUserImage: (img) => {
        window.localStorage.setItem('userImg', JSON.stringify(img));
    },

    getUserImage: () => {
        return JSON.parse(window.localStorage.getItem('userImg'));
    },
};

export default App;