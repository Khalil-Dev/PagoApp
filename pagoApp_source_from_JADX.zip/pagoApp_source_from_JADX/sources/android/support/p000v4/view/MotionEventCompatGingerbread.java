package android.support.p000v4.view;

import android.view.MotionEvent;

/* renamed from: android.support.v4.view.MotionEventCompatGingerbread */
class MotionEventCompatGingerbread {
    MotionEventCompatGingerbread() {
    }

    public static int getSource(MotionEvent event) {
        return event.getSource();
    }
}
