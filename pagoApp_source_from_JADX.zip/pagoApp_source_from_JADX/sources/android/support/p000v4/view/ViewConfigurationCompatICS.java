package android.support.p000v4.view;

import android.view.ViewConfiguration;

/* renamed from: android.support.v4.view.ViewConfigurationCompatICS */
class ViewConfigurationCompatICS {
    ViewConfigurationCompatICS() {
    }

    static boolean hasPermanentMenuKey(ViewConfiguration config) {
        return config.hasPermanentMenuKey();
    }
}
