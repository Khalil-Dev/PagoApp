package android.support.p000v4.widget;

import android.widget.ListView;

/* renamed from: android.support.v4.widget.ListViewCompatKitKat */
class ListViewCompatKitKat {
    ListViewCompatKitKat() {
    }

    static void scrollListBy(ListView listView, int y) {
        listView.scrollListBy(y);
    }
}
