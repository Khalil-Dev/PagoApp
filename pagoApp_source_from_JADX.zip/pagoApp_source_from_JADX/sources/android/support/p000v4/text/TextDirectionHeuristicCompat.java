package android.support.p000v4.text;

/* renamed from: android.support.v4.text.TextDirectionHeuristicCompat */
public interface TextDirectionHeuristicCompat {
    boolean isRtl(CharSequence charSequence, int i, int i2);

    boolean isRtl(char[] cArr, int i, int i2);
}
