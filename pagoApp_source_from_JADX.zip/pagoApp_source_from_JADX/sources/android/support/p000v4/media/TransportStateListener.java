package android.support.p000v4.media;

/* renamed from: android.support.v4.media.TransportStateListener */
public class TransportStateListener {
    public void onPlayingChanged(TransportController controller) {
    }

    public void onTransportControlsChanged(TransportController controller) {
    }
}
