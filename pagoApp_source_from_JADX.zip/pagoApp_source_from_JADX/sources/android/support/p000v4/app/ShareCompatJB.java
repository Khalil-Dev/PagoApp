package android.support.p000v4.app;

import android.text.Html;

/* renamed from: android.support.v4.app.ShareCompatJB */
class ShareCompatJB {
    ShareCompatJB() {
    }

    public static String escapeHtml(CharSequence html) {
        return Html.escapeHtml(html);
    }
}
