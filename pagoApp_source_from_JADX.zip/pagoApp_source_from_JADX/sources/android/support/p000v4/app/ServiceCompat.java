package android.support.p000v4.app;

/* renamed from: android.support.v4.app.ServiceCompat */
public final class ServiceCompat {
    public static final int START_STICKY = 1;

    private ServiceCompat() {
    }
}
