package android.support.p000v4.app;

/* renamed from: android.support.v4.app.NotificationManagerCompatIceCreamSandwich */
class NotificationManagerCompatIceCreamSandwich {
    static final int SIDE_CHANNEL_BIND_FLAGS = 33;

    NotificationManagerCompatIceCreamSandwich() {
    }
}
