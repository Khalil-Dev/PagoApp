package android.support.p000v4.app;

/* renamed from: android.support.v4.app.NotificationCompatApi23 */
class NotificationCompatApi23 {
    public static final String CATEGORY_REMINDER = "reminder";

    NotificationCompatApi23() {
    }
}
